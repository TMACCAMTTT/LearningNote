#-*-coding:utf-8-*-
import numpy as np

a = [2,3,5]
median = np.median(a)
print(median)